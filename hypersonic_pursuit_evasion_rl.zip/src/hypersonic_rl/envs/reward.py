"""
reward.py

作用：
    统一管理追逃突防环境的奖励函数。

当前版本：
    默认奖励对齐论文第 5 章端到端 SAC 任务：
        1. 过程奖励约束红方横向过载；
        2. 过程奖励鼓励红方继续接近预设打击目标；
        3. 终端奖励同时考虑两枚拦截弹的连续最小脱靶量；
        4. 任一拦截弹进入杀伤半径即判定突防失败。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import numpy as np


@dataclass
class RewardConfig:
    """
    RewardConfig

    作用：
        管理端到端突防奖励函数的全部系数。

    设计原则：
        1. 第一优先级：不能被任一拦截弹命中；
        2. 第二优先级：突防后尽量保持任务方向，继续接近预设目标；
        3. 第三优先级：减少不必要的大幅横向机动。
    """

    # 过程项：红方横向过载惩罚。
    stage_action_weight: float = 0.02

    # 过程项：接近预设打击目标奖励。
    # 说明：
    #     原来 0.002 偏大，容易让“直飞但被拦截”的累计奖励过高。
    stage_target_weight: float = 0.0005

    # 单枚弹脱靶量终端奖励。
    terminal_large_miss_slope: float = 0.02
    terminal_large_miss_bias: float = 50.6
    terminal_ideal_miss_slope: float = 1.0
    terminal_ideal_miss_bias: float = 20.0

    # 单枚弹进入杀伤半径时的局部惩罚。
    terminal_failure_penalty: float = 30.0

    # 全局突防成败奖励。
    # 说明：
    #     任一拦截弹进入杀伤半径，给全局失败惩罚；
    #     所有拦截弹均错过并自然终止，给全局成功奖励。
    terminal_intercept_penalty: float = 250.0
    terminal_success_bonus: float = 200.0

    # 理想脱靶量。
    ideal_miss_distance: float = 50.0

    # 杀伤半径。
    kill_radius: float = 5.0


def compute_control_energy(control_trace: Iterable[float], dt: float) -> float:
    """
    计算控制能耗近似值。

    参数：
        control_trace：
            控制量序列。
        dt：
            仿真步长，单位 s。

    返回：
        control_energy：
            使用 sum(u^2) * dt 得到的离散控制能耗。
    """
    # control_array：把输入序列统一转成浮点数组。
    control_array = np.asarray(list(control_trace), dtype=np.float64)

    if control_array.size == 0:
        return 0.0

    # control_energy：平方积分近似。
    control_energy = float(np.sum(np.square(control_array)) * float(dt))

    return control_energy


def compute_success(min_distance: float, kill_radius: float) -> float:
    """
    根据全局最小距离判断红方是否突防成功。

    参数：
        min_distance：
            所有拦截弹中的全局连续最小距离。
        kill_radius：
            杀伤半径。

    返回：
        success：
            1.0 表示未被任何拦截弹命中，0.0 表示被拦截。
    """
    # success：任一弹进入杀伤半径即失败。
    success = 1.0 if float(min_distance) > float(kill_radius) else 0.0

    return success


def _terminal_reward_for_miss_distance(miss_distance: float, config: RewardConfig) -> float:
    """
    计算单枚拦截弹脱靶量对应的终端奖励。

    参数：
        miss_distance：
            当前拦截弹的连续最小脱靶量。
        config：
            奖励函数配置。

    返回：
        terminal_reward：
            单枚弹终端奖励。
    """
    # miss：统一转成非负浮点数，避免异常输入污染奖励。
    miss = max(float(miss_distance), 0.0)

    if miss < config.kill_radius:
        # 失败区间：进入杀伤半径，给固定负奖励。
        return -float(config.terminal_failure_penalty)

    if miss <= config.ideal_miss_distance:
        # 理想区间：脱靶量越大越安全，但仍保持在任务可接受范围内。
        return (
            float(config.terminal_ideal_miss_slope) * miss
            + float(config.terminal_ideal_miss_bias)
        )

    # 过大区间：脱靶量过大代表红方偏离任务弹道，因此奖励开始下降。
    terminal_reward = (
        -float(config.terminal_large_miss_slope) * miss
        + float(config.terminal_large_miss_bias)
    )

    return float(terminal_reward)


def calculate_end_to_end_reward(
    red_lateral_overload: float,
    previous_target_distance: float,
    current_target_distance: float,
    interceptor_min_distances: List[float],
    terminated: bool,
    config: RewardConfig,
) -> Tuple[float, Dict[str, float]]:
    """
    计算端到端突防任务的单步奖励。

    奖励设计：
        1. 过程阶段：
            - 惩罚红方横向机动能耗；
            - 轻微鼓励红方继续接近预设打击目标。

        2. 终端阶段：
            - 如果任一拦截弹进入杀伤半径，判定突防失败，给全局强惩罚；
            - 如果所有拦截弹均错过，判定突防成功，给全局成功奖励；
            - 同时保留逐枚拦截弹脱靶量奖励，用于区分“刚好突防”和“较安全突防”。

    说明：
        当前环境中 terminated=True 只可能来自：
            1. 任一拦截弹命中；
            2. 所有拦截弹错过。
        因此可以用 global_min_distance <= kill_radius 判断是否被拦截。
    """
    # ------------------------------------------------------------
    # 1. 过程奖励：控制能耗约束
    # ------------------------------------------------------------
    action_penalty = (
        -float(config.stage_action_weight)
        * abs(float(red_lateral_overload))
    )

    # ------------------------------------------------------------
    # 2. 过程奖励：接近预设打击目标
    # ------------------------------------------------------------
    target_progress = (
        float(previous_target_distance)
        - float(current_target_distance)
    )

    target_progress_reward = (
        float(config.stage_target_weight)
        * target_progress
    )

    # ------------------------------------------------------------
    # 3. 全局最小脱靶量与成败判定
    # ------------------------------------------------------------
    if interceptor_min_distances:
        global_min_distance = float(min(interceptor_min_distances))
    else:
        global_min_distance = np.inf

    intercepted = bool(global_min_distance <= float(config.kill_radius))

    # success 只在自然终止且未被拦截时成立。
    # 也就是说，所有拦截弹都已经 passed。
    success = bool(terminated and not intercepted)

    # ------------------------------------------------------------
    # 4. 终端奖励
    # ------------------------------------------------------------
    terminal_reward = 0.0
    terminal_global_reward = 0.0
    terminal_rewards: List[float] = []

    if terminated:
        for miss_distance in interceptor_min_distances:
            per_reward = _terminal_reward_for_miss_distance(
                miss_distance=miss_distance,
                config=config,
            )
            terminal_rewards.append(per_reward)

        terminal_distance_reward = (
            float(np.sum(terminal_rewards))
            if terminal_rewards
            else 0.0
        )

        if intercepted:
            terminal_global_reward = -float(config.terminal_intercept_penalty)
        else:
            terminal_global_reward = float(config.terminal_success_bonus)

        terminal_reward = terminal_distance_reward + terminal_global_reward

    else:
        terminal_distance_reward = 0.0

    # ------------------------------------------------------------
    # 5. 总奖励
    # ------------------------------------------------------------
    reward = (
        action_penalty
        + target_progress_reward
        + terminal_reward
    )

    # ------------------------------------------------------------
    # 6. 奖励诊断信息
    # ------------------------------------------------------------
    reward_info: Dict[str, float] = {
        "reward": float(reward),

        "action_penalty": float(action_penalty),
        "target_progress_reward": float(target_progress_reward),
        "target_progress": float(target_progress),
        "previous_target_distance": float(previous_target_distance),
        "target_distance": float(current_target_distance),

        "terminal_reward": float(terminal_reward),
        "terminal_distance_reward": float(terminal_distance_reward),
        "terminal_global_reward": float(terminal_global_reward),

        "min_distance": float(global_min_distance),
        "intercepted_reward_flag": float(intercepted),
        "success_reward_flag": float(success),
    }

    for index, per_reward in enumerate(terminal_rewards, start=1):
        reward_info[f"interceptor_{index}_terminal_reward"] = float(per_reward)

    return float(reward), reward_info
