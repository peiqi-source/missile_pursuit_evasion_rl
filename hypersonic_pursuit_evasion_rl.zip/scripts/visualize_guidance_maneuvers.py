import argparse
import csv
import sys
from pathlib import Path
from typing import Callable, Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


# ---------------------------------------------------------------------
# 路径处理：保证直接运行 scripts/xxx.py 时可以找到 src/hypersonic_rl
# ---------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


from hypersonic_rl.envs.pursue_escape_env import PursueEscapeEnv, PursueEscapeEnvConfig
from hypersonic_rl.visualization.plot_episode import plot_episode_summary
from hypersonic_rl.visualization.plot_trajectory import (
    INTERCEPTOR_COLORS,
    RED_COLOR,
    extract_multi_trajectories_from_env,
    plot_full_trajectory_summary,
)


# ---------------------------------------------------------------------
# 红方固定机动策略
# ---------------------------------------------------------------------
def red_level_flight(t: float, max_overload: float) -> float:
    """
    平飞：红方不主动侧向机动。
    """
    return 0.0


def red_sine_maneuver(t: float, max_overload: float) -> float:
    """
    正弦机动：红方侧向过载按正弦变化。
    """
    amplitude = 0.75 * float(max_overload)
    frequency_hz = 0.08

    return float(amplitude * np.sin(2.0 * np.pi * frequency_hz * t))


def red_bangbang_maneuver(t: float, max_overload: float) -> float:
    """
    bang-bang 机动：红方每隔固定时间在正负最大过载之间切换。
    """
    switch_period = 4.0
    segment_index = int(t // switch_period)

    if segment_index % 2 == 0:
        return float(max_overload)

    return -float(max_overload)


def red_left_full(t: float, max_overload: float) -> float:
    """
    左打满：红方持续给正向最大侧向过载。
    """
    return float(max_overload)


def red_right_full(t: float, max_overload: float) -> float:
    """
    右打满：红方持续给负向最大侧向过载。
    """
    return -float(max_overload)


MANEUVER_POLICIES: Dict[str, Callable[[float, float], float]] = {
    "level_flight": red_level_flight,
    "sine": red_sine_maneuver,
    "bangbang": red_bangbang_maneuver,
    "left_full": red_left_full,
    "right_full": red_right_full,
}


GUIDANCE_MODES: List[str] = [
    "source_pn",
    "mid_terminal_interceptor",
    "paper_mid_terminal",
]


def parse_args() -> argparse.Namespace:
    """
    解析命令行参数，让调试脚本可以显式切换拦截弹数量和对比范围。

    返回：
        args：
            argparse 解析后的参数对象。
    """
    # parser：脚本级命令行入口。
    parser = argparse.ArgumentParser(
        description="可视化不同红方机动下的拦截弹制导轨迹，可显式选择 1 枚或 2 枚拦截弹。",
    )

    # interceptor-count：用于在单弹 debug 和双弹论文态势之间切换。
    parser.add_argument(
        "--interceptor-count",
        type=int,
        choices=[1, 2],
        default=1,
        help="拦截弹数量，支持 1 或 2，默认 1。",
    )

    # guidance-modes：允许只跑某一个制导模式，避免每次都跑完整矩阵。
    parser.add_argument(
        "--guidance-modes",
        nargs="+",
        choices=GUIDANCE_MODES,
        default=list(GUIDANCE_MODES),
        help="需要对比的蓝方制导模式。",
    )

    # maneuvers：允许只跑 level_flight 等单个红方机动。
    parser.add_argument(
        "--maneuvers",
        nargs="+",
        choices=list(MANEUVER_POLICIES.keys()),
        default=list(MANEUVER_POLICIES.keys()),
        help="需要运行的红方固定机动策略。",
    )

    # scenario-profile：默认使用论文 200 km 态势，也可切换 manual/custom。
    parser.add_argument(
        "--scenario-profile",
        choices=["paper_200km_end_to_end", "manual_pair", "custom"],
        default="paper_200km_end_to_end",
        help="初始态势 profile。",
    )

    # ability-profile：蓝方能力档位。
    parser.add_argument(
        "--interceptor-ability-profile",
        choices=["weak", "paper", "strong", "custom"],
        default="paper",
        help="蓝方能力档位。",
    )

    # seed：固定随机种子，便于复现实验。
    parser.add_argument(
        "--seed",
        type=int,
        default=0,
        help="环境随机种子。",
    )

    # max-time/dt：仿真时间和积分步长。
    parser.add_argument(
        "--max-time",
        type=float,
        default=80.0,
        help="单回合最大仿真时长，单位 s。",
    )
    parser.add_argument(
        "--dt",
        type=float,
        default=0.02,
        help="仿真步长，单位 s。",
    )

    # output-dir：显式指定结果目录；不指定时按拦截弹数量自动命名。
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="输出目录；相对路径会解析到项目根目录下。",
    )

    return parser.parse_args()


def resolve_output_dir(output_dir: Path | None, interceptor_count: int) -> Path:
    """
    根据命令行参数生成最终输出目录。

    参数：
        output_dir：
            用户显式传入的输出目录；None 表示使用默认目录。
        interceptor_count：
            当前运行使用的拦截弹数量。

    返回：
        resolved_dir：
            绝对输出目录。
    """
    if output_dir is None:
        # resolved_dir：默认目录带上 missile 数量，避免单弹和双弹结果互相覆盖。
        resolved_dir = PROJECT_ROOT / "outputs" / f"guidance_maneuver_visualization_{interceptor_count}missile"
    elif output_dir.is_absolute():
        # resolved_dir：绝对路径按用户输入保留。
        resolved_dir = output_dir
    else:
        # resolved_dir：相对路径统一放在项目根目录下，方便管理实验输出。
        resolved_dir = PROJECT_ROOT / output_dir

    return resolved_dir


# ---------------------------------------------------------------------
# 单次仿真
# ---------------------------------------------------------------------
def run_single_case(
    guidance_mode: str,
    maneuver_name: str,
    maneuver_policy: Callable[[float, float], float],
    seed: int = 0,
    interceptor_count: int = 1,
    scenario_profile: str = "paper_200km_end_to_end",
    interceptor_ability_profile: str = "paper",
    max_time: float = 80.0,
    dt: float = 0.02,
) -> Tuple[PursueEscapeEnv, Dict[str, object]]:
    """
    运行单个红方机动 + 蓝方制导模式组合。
    """
    # config：当前 case 的环境配置，拦截弹数量由命令行显式控制。
    config = PursueEscapeEnvConfig(
        guidance_mode=guidance_mode,
        initial_randomization_enabled=False,
        interceptor_count=int(interceptor_count),
        scenario_profile=scenario_profile,
        interceptor_ability_profile=interceptor_ability_profile,
        paper_downward_bias_ratio=0.7,

        # t/dt：先用较完整的时长观察命中/错过，命令行可覆盖为短回合 debug。
        t=float(max_time),
        dt=float(dt),
    )

    # env：追逃突防环境。
    env = PursueEscapeEnv(config=config)

    # observation/info：初始状态和诊断信息。
    observation, info = env.reset(seed=seed)

    # terminated/truncated：Gymnasium 标准终止标志。
    terminated = False
    truncated = False

    # reward：记录最后一步奖励，便于 summary 快速查看。
    reward = 0.0

    # last_info：记录最后一步环境诊断。
    last_info = dict(info)

    for _ in range(env.max_steps):
        # current_time：当前仿真时间，用于红方固定机动策略。
        current_time = float(env.current_time)

        # red_command：红方横向过载指令，单位 g。
        red_command = maneuver_policy(
            current_time,
            float(env.config.nzc_h_max),
        )

        # action：环境动作接口仍保持 1 维。
        action = np.array([red_command], dtype=np.float32)

        observation, reward, terminated, truncated, last_info = env.step(action)

        if terminated or truncated:
            break

    if len(env.distance_trace) > 0:
        sampled_min_distance = float(np.nanmin(np.asarray(env.distance_trace, dtype=np.float64)))
        final_distance = float(env.distance_trace[-1])
    else:
        sampled_min_distance = np.nan
        final_distance = np.nan

    continuous_min_distance = float(last_info.get("min_distance", env.min_distance))

    summary: Dict[str, object] = {
        "maneuver_name": maneuver_name,
        "guidance_mode": guidance_mode,
        "interceptor_count": int(env.config.interceptor_count),
        "min_distance": continuous_min_distance,
        "continuous_min_distance": continuous_min_distance,
        "sampled_min_distance": sampled_min_distance,
        "final_distance": final_distance,
        "final_time": float(env.current_time),
        "reward": float(reward),
        "terminated": bool(terminated),
        "truncated": bool(truncated),
        "success": bool(last_info.get("success", False)),
        "intercepted": bool(last_info.get("intercepted", False)),
        "termination_reason": str(last_info.get("termination_reason", "unknown")),
        "threat_interceptor_id": int(last_info.get("threat_interceptor_id", 0)),
    }

    for key, value in last_info.items():
        if (
            key.endswith("intercepted")
            or key.endswith("passed")
            or key.endswith("min_distance")
            or key.endswith("phase")
        ):
            summary[key] = value

    return env, summary


# ---------------------------------------------------------------------
# 同一红方机动下，对比三种蓝方制导模式的 X-Z 轨迹
# ---------------------------------------------------------------------
def plot_guidance_comparison_xz(
    maneuver_name: str,
    env_by_guidance: Dict[str, PursueEscapeEnv],
    save_path: Path,
) -> Path:
    """
    将同一红方机动下的三种制导模式画在同一张 X-Z 俯视图中。
    """
    save_path.parent.mkdir(parents=True, exist_ok=True)

    figure, ax = plt.subplots(figsize=(10, 7))

    red_plotted = False

    for guidance_index, (guidance_mode, env) in enumerate(env_by_guidance.items()):
        red_trajectory, interceptor_trajectories = extract_multi_trajectories_from_env(env)

        if (not red_plotted) and red_trajectory.size > 0:
            ax.plot(
                red_trajectory[:, 0] / 1000.0,
                red_trajectory[:, 2],
                color=RED_COLOR,
                linewidth=2.3,
                label="Red trajectory",
            )
            ax.scatter(
                red_trajectory[0, 0] / 1000.0,
                red_trajectory[0, 2],
                color=RED_COLOR,
                marker="o",
                s=35,
                label="Red start",
            )
            ax.scatter(
                red_trajectory[-1, 0] / 1000.0,
                red_trajectory[-1, 2],
                color=RED_COLOR,
                marker="x",
                s=45,
                label="Red end",
            )
            red_plotted = True

        for interceptor_index, trajectory in enumerate(interceptor_trajectories, start=1):
            if trajectory.size == 0:
                continue

            color = INTERCEPTOR_COLORS[
                (guidance_index * 2 + interceptor_index - 1) % len(INTERCEPTOR_COLORS)
            ]

            ax.plot(
                trajectory[:, 0] / 1000.0,
                trajectory[:, 2],
                color=color,
                linewidth=1.4,
                label=f"{guidance_mode} - I{interceptor_index}",
            )

    ax.set_title(f"Guidance comparison in X-Z plane | {maneuver_name}")
    ax.set_xlabel("X forward distance (km)")
    ax.set_ylabel("Z lateral distance (m)")
    ax.grid(True)
    ax.legend(fontsize=7)

    figure.tight_layout()
    figure.savefig(save_path, dpi=220)
    plt.close(figure)

    return save_path


def save_summary_csv(
    summaries: List[Dict[str, object]],
    save_path: Path,
) -> Path:
    """
    保存所有 case 的 summary。
    """
    save_path.parent.mkdir(parents=True, exist_ok=True)

    base_keys = [
        "maneuver_name",
        "guidance_mode",
        "interceptor_count",
        "min_distance",
        "continuous_min_distance",
        "sampled_min_distance",
        "final_distance",
        "final_time",
        "reward",
        "terminated",
        "truncated",
        "success",
        "intercepted",
        "termination_reason",
        "threat_interceptor_id",
    ]

    # extra_keys：动态保留每枚拦截弹自己的命中、错过、阶段和最小距离字段。
    extra_keys = sorted(
        {
            key
            for item in summaries
            for key in item.keys()
            if key not in base_keys
        }
    )

    # keys：CSV 最终字段顺序，基础字段在前，诊断字段在后。
    keys = base_keys + extra_keys

    with save_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=keys)
        writer.writeheader()
        for item in summaries:
            writer.writerow({key: item.get(key, "") for key in keys})

    return save_path


def main() -> None:
    """
    脚本主入口：批量运行红方机动和蓝方制导模式组合并保存图像。

    返回：
        None。
    """
    # args：命令行参数。
    args = parse_args()

    # root_output_dir：本次实验的根输出目录。
    root_output_dir = resolve_output_dir(args.output_dir, args.interceptor_count)

    # comparison_output_dir：同一红方机动下的制导模式对比图目录。
    comparison_output_dir = root_output_dir / "_comparisons_by_maneuver"
    root_output_dir.mkdir(parents=True, exist_ok=True)
    comparison_output_dir.mkdir(parents=True, exist_ok=True)

    # selected_maneuvers/selected_guidance_modes：去重后保持输入顺序。
    selected_maneuvers = list(dict.fromkeys(args.maneuvers))
    selected_guidance_modes = list(dict.fromkeys(args.guidance_modes))

    print("=" * 80)
    print(
        "Visualization config: "
        f"interceptor_count={args.interceptor_count}, "
        f"scenario_profile={args.scenario_profile}, "
        f"ability_profile={args.interceptor_ability_profile}, "
        f"seed={args.seed}, "
        f"max_time={args.max_time}, "
        f"dt={args.dt}"
    )
    print(f"Guidance modes: {selected_guidance_modes}")
    print(f"Maneuvers: {selected_maneuvers}")

    # all_summaries：所有 case 的总表。
    all_summaries: List[Dict[str, object]] = []

    # summaries_by_guidance：按制导模式拆分保存 summary。
    summaries_by_guidance: Dict[str, List[Dict[str, object]]] = {
        guidance_mode: []
        for guidance_mode in selected_guidance_modes
    }

    for maneuver_name in selected_maneuvers:
        # maneuver_policy：当前红方固定机动策略。
        maneuver_policy = MANEUVER_POLICIES[maneuver_name]

        # env_by_guidance：保存同一红方机动下各制导模式环境，用于画对比图。
        env_by_guidance: Dict[str, PursueEscapeEnv] = {}

        for guidance_mode in selected_guidance_modes:
            print("=" * 80)
            print(
                f"Running maneuver={maneuver_name}, "
                f"guidance={guidance_mode}, "
                f"interceptor_count={args.interceptor_count}"
            )

            env, summary = run_single_case(
                guidance_mode=guidance_mode,
                maneuver_name=maneuver_name,
                maneuver_policy=maneuver_policy,
                seed=args.seed,
                interceptor_count=args.interceptor_count,
                scenario_profile=args.scenario_profile,
                interceptor_ability_profile=args.interceptor_ability_profile,
                max_time=args.max_time,
                dt=args.dt,
            )

            env_by_guidance[guidance_mode] = env
            all_summaries.append(summary)
            summaries_by_guidance[guidance_mode].append(summary)

            # 按制导方式分文件夹输出。
            guidance_output_dir = root_output_dir / guidance_mode
            guidance_output_dir.mkdir(parents=True, exist_ok=True)

            case_prefix = f"{maneuver_name}"

            plot_episode_summary(
                env=env,
                save_path=guidance_output_dir / f"{case_prefix}__episode_summary.png",
                title=f"{maneuver_name} | {guidance_mode}",
                show=False,
            )

            plot_full_trajectory_summary(
                env=env,
                save_path=guidance_output_dir / f"{case_prefix}__full_trajectory.png",
                show=False,
            )

            print(
                f"min_distance={float(summary['min_distance']):.3f} m, "
                f"sampled_min_distance={float(summary['sampled_min_distance']):.3f} m, "
                f"final_time={float(summary['final_time']):.3f} s, "
                f"terminated={summary['terminated']}, "
                f"truncated={summary['truncated']}"
            )

        plot_guidance_comparison_xz(
            maneuver_name=maneuver_name,
            env_by_guidance=env_by_guidance,
            save_path=comparison_output_dir / f"{maneuver_name}__guidance_comparison_xz.png",
        )

    # 总表。
    summary_path = save_summary_csv(
        summaries=all_summaries,
        save_path=root_output_dir / "summary_all.csv",
    )

    # 每个制导方式单独保存 summary。
    for guidance_mode, guidance_summaries in summaries_by_guidance.items():
        save_summary_csv(
            summaries=guidance_summaries,
            save_path=root_output_dir / guidance_mode / "summary.csv",
        )

    print("=" * 80)
    print(f"All figures saved to: {root_output_dir}")
    print(f"Comparison figures saved to: {comparison_output_dir}")
    print(f"Summary saved to: {summary_path}")


if __name__ == "__main__":
    main()
